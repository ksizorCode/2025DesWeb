<?php $t='contacto'?>
<?php require 'bloques/_config.php'?>
<?php include_once 'bloques/_header.php';?>
<address>una pijada</address>
<?php include_once 'bloques/_footer.php';?>