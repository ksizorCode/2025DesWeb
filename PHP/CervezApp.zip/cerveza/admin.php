<?php $t='admin'?>
<?php require 'bloques/_config.php'?>
<?php include_once 'bloques/_header.php';?>
<?php include_once 'bloques/_footer.php';?>