</main>
<footer>
    <p>&copy; <?php echo date('Y').' '.$t?></p>
</footer>
</body>
</html>